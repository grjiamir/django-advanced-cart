====================
Django Advanced Cart
====================

Django Advanced Cart is a Django app to store product in cart.


Quick start
-----------

1. Add "advanced_cart" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'advanced_cart',
    ]

    Add below line to settings::
        CART_SESSION_ID = 'cart'



